<?php
  header($_SERVER["SERVER_PROTOCOL"] . " 403");
  exit;
?>