<?php

    session_start();
    header($_SERVER["SERVER_PROTOCOL"] . " 403");
    exit;

?>